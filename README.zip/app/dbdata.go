package app

import (
//"time"
)

type DbData struct {
	ID   int    `"id"`
	Name string `json:"first_name"`
}
